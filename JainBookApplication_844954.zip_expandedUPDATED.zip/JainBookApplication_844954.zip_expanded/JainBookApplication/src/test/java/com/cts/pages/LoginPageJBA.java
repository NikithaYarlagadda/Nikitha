package com.cts.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;

public class LoginPageJBA {
private  By emailLoc = By.id("ContentPlaceHolder1_TextBox1");
private  By passwordLoc = By.id("ContentPlaceHolder1_TextBox2");
private  By submitLoc =By.id("ContentPlaceHolder1_btnlogin");
private  By myaccountLoc = By.linkText("My Account");
private  By logoutLoc = By.id("logout");


public  void logoutdetails(WebDriver driver)
{
Actions act = new Actions(driver);
act.moveToElement(driver.findElement(myaccountLoc)).build().perform();
driver.findElement(logoutLoc).click();
}
public  void loginDetails(WebDriver driver, String email, String password)
{
driver.findElement(emailLoc).sendKeys(email);
driver.findElement(passwordLoc).sendKeys(password);
driver.findElement(submitLoc).click();

}
}
